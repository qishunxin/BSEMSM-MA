
###############################a#################################S1

load("D:\\Desktop\\MULTI-STATE-电脑2\\元旦后最后一次修改\\次要问题一——箱线图绘制_原程序\\lam.c共轭gibbs-n=500,,h=2T+1\\100.Rdata")
 

library(MASS)
library(HI)
library(coda)
library(MCMCpack)

values <- list(0, 1)

# 定义循环次数
loop <- 100 # 假设进行100次循环/模拟

# 创建数组存储多次模拟结果
# 维度：[循环次数, z_z, z_s, z_m]
loop_E1 <- array(0, dim = c(loop, length(values), length(values), length(values)))
loop_tE1 <- array(0, dim = c(loop, length(values), length(values), length(values)))

surv_prob1 <- function(z_z, z_s, x, hpost, AT, DeltaT, omega, cpsd) {
    nhcut <- 5
    t <- median(X[, 1])
    hcut <- quantile(X[, 1], seq(0, 1, 1 / nhcut))
    
    idx <- sum(t > hcut)
    idx <- min(idx, length(hcut) - 1)
    trpz_itgr <- 0.5 * t * (hpost[1] + hpost[idx])
    
    beta_0 = cbind(DeltaT[1], DeltaT[8])
    beta_x = cbind(DeltaT[2:5], DeltaT[9:12])
    beta_s1 = cbind(DeltaT[6], DeltaT[13])
    
    cAT = AT[1:4]
    zAT1 = AT[5]
    mAT1 = AT[7:8]
    
    M_X1 <- beta_0 + x %*% beta_x + z_s %*% beta_s1 + 
            mvrnorm(1, rep(0, q), diag(cpsd, q))
    
    ypost1 <- x %*% cAT + z_z %*% zAT1 + M_X1 %*% mAT1 + omega
 
    sur_prob1 <- colMeans(exp(-as.vector(trpz_itgr) %*% exp(ypost1)))
    return(sur_prob1)
}


# 外部循环 - 多次模拟
for (loopp in 1:loop) {
    cat("循环 ", loopp, "/", loop, "\n")
     set.seed(201 + crep *10)  
    # 为当前循环初始化临时数组
    parsur_temp <- array(0, dim = c(length(values), length(values), length(values)))
    surv_temp <- array(0, dim = c(length(values), length(values), length(values)))
    
    # 遍历所有组合
    for (z_z_index in seq_along(values)) {
        for (z_s_index in seq_along(values)) {
            for (z_m_index in seq_along(values)) {
                
                z_z <- values[[z_z_index]]
                z_s <- values[[z_s_index]]
                z_m <- values[[z_m_index]]
                
                # 对每个个体计算
                individual_estimates <- numeric(n)
                individual_true <- numeric(n)
                
                for (i in 1:n) {
                    # 计算估计值
                    est <- surv_prob1(z_z, z_s, Z[i, ], 
                                      mean.lam0.a[loopp, ], 
                                      mean.gam.a[loopp,], 
                                      mean.L.se[loopp,], 
                                      omegaT[i], 
                                      mean.psd[loopp,])
                    
                    # 计算真实值
                    true_val <- surv_prob1(z_z, z_s, Z[i, ], 
                                          lam0.true.a, 
                                          gam.true.a, 
                                          c(L.se.true[1,], L.se.true[2,]), 
                                          omegaT[i], 
                                          psd.true)
                    
                    individual_estimates[i] <- est
                    individual_true[i] <- true_val
                }
                
                # 计算平均值并存储
                parsur_temp[z_z_index, z_s_index, z_m_index] <- mean(individual_estimates)
                surv_temp[z_z_index, z_s_index, z_m_index] <- mean(individual_true)
            }
        }
    }
    
    # 存储当前循环的结果
    loop_E1[loopp, , , ] <- parsur_temp
    loop_tE1[loopp, , , ] <- surv_temp
}

# 计算总结统计量
# 1. 计算均值估计
E1 <- apply(loop_E1, c(2, 3, 4), mean)  # 平均估计值
tE1 <- apply(loop_tE1, c(2, 3, 4), mean)  # 平均真实值

# 2. 计算标准差
parsee_E1 <- apply(loop_E1, c(2, 3, 4), sd)  # 估计值的标准差

# 3. 计算每个位置的RMSE
RMSE_array <- array(0, dim = c(length(values), length(values), length(values)))

for (i in 1:length(values)) {
    for (j in 1:length(values)) {
        for (k in 1:length(values)) {
            # 提取所有循环中该位置的估计值
            estimates <- loop_E1[, i, j, k]
            true_values <- loop_tE1[, i, j, k]
            
            # 计算RMSE
            RMSE_array[i, j, k] <- sqrt(mean((estimates - true_values)^2))
        }
    }
}

cat("\n=== 计算结果 ===\n")
cat("E1 (平均估计值):\n")
print(E1)

cat("\ntE1 (平均真实值):\n")
print(tE1)

cat("\nparsee_E1 (估计值标准差):\n")
print(parsee_E1)

cat("\nRMSE_array (均方根误差):\n")
print(RMSE_array)

# 计算效果量
# 假设位置对应关系：1对应值0，2对应值1
# 总效应：E[1,1,1] -> E[2,2,2]
ete_draws <- loop_E1[, 2, 2, 2] - loop_E1[, 1, 1, 1]
ede_draws <- loop_E1[, 2, 2, 2] - loop_E1[, 1, 2, 2]
eie1_m1_draws <- loop_E1[, 2, 2, 2] - loop_E1[, 2, 1, 2]
eie1_m2_draws <- loop_E1[, 2, 2, 2] - loop_E1[, 2, 2, 1]

# 真实效果量
true_ete <- tE1[2, 2, 2] - tE1[1, 1, 1]
true_ede <- tE1[2, 2, 2] - tE1[1, 2, 2]
true_eie_m1 <- tE1[2, 2, 2] - tE1[2, 1, 2]
true_eie_m2 <- tE1[2, 2, 2] - tE1[2, 2, 1]

# 计算RMSE
RMSE_ete1 <- sqrt(mean((ete_draws - true_ete)^2))
RMSE_ede1 <- sqrt(mean((ede_draws - true_ede)^2))
RMSE_eie1_m1 <- sqrt(mean((eie1_m1_draws - true_eie_m1)^2))
RMSE_eie1_m2 <- sqrt(mean((eie1_m2_draws - true_eie_m2)^2))

# 其他统计量
mean_ete1 <- mean(ete_draws)
mean_ede1 <- mean(ede_draws)
mean_eie1_m1 <- mean(eie1_m1_draws)
mean_eie1_m2 <- mean(eie1_m2_draws)

bias_ete1 <- mean_ete1 - true_ete
bias_ede1 <- mean_ede1 - true_ede
bias_eie1_m1 <- mean_eie1_m1 - true_eie_m1
bias_eie1_m2 <- mean_eie1_m2 - true_eie_m2

sd_ete1 <- sd(ete_draws)
sd_ede1 <- sd(ede_draws)
sd_eie1_m1 <- sd(eie1_m1_draws)
sd_eie1_m2 <- sd(eie1_m2_draws)

# 创建结果表格
result1 <- data.frame(
  Effect = c("Total_Effect", "Direct_Effect", "IE_via_M1", "IE_via_M2"),
  True_Value = c(true_ete, true_ede, true_eie_m1, true_eie_m2),
  Estimate = c(mean_ete1, mean_ede1, mean_eie1_m1, mean_eie1_m2),
  Bias = c(bias_ete1, bias_ede1, bias_eie1_m1, bias_eie1_m2),
  RMSE = c(RMSE_ete1, RMSE_ede1, RMSE_eie1_m1, RMSE_eie1_m2),
  SD = c(sd_ete1, sd_ede1, sd_eie1_m1, sd_eie1_m2)
)

cat("\n=== 效果量分析 ===\n")
print(result1)




###############################b#################################
load("D:\\Desktop\\MULTI-STATE-电脑2\\元旦后最后一次修改\\次要问题一——箱线图绘制_原程序\\lam.c共轭gibbs-n=500,,h=2T+1\\100.Rdata")

library(MASS)
library(HI)
library(coda)
library(MCMCpack)

values <- list(0, 1)

# 定义循环次数
loop <- 100  # 假设进行100次循环/模拟

# 创建数组存储多次模拟结果
# 维度：[循环次数, z_z, z_s, z_m]
loop_E1 <- array(0, dim = c(loop, length(values), length(values), length(values)))
loop_tE1 <- array(0, dim = c(loop, length(values), length(values), length(values)))

surv_prob1 <- function(z_z, z_s, x, hpost, AT, DeltaT, omega, cpsd, calpha1t) {
    nhcut <- 5
    t <- median(X[, 1])
    hcut <- quantile(X[, 1], seq(0, 1, 1 / nhcut))
    
    idx <- sum(t > hcut)
    idx <- min(idx, length(hcut) - 1)
    trpz_itgr <- 0.5 * t * (hpost[1] + hpost[idx])
    
    beta_0 = cbind(DeltaT[1], DeltaT[8])
    beta_x = cbind(DeltaT[2:5], DeltaT[9:12])
    beta_s1 = cbind(DeltaT[6], DeltaT[13])
    
    cAT = AT[1:4]
    zAT1 = AT[5]
    mAT1 = AT[7:8]
    
    M_X1 <- beta_0 + x %*% beta_x + z_s %*% beta_s1 + 
            mvrnorm(1, rep(0, q), diag(cpsd, q))
    
    ypost1 <- x %*% cAT + z_z %*% zAT1 + M_X1 %*% mAT1 + calpha1t * omega
 
    sur_prob1 <- colMeans(exp(-as.vector(trpz_itgr) %*% exp(ypost1)))
    return(sur_prob1)
}


 

# 外部循环 - 多次模拟
for (loopp in 1:loop) {
    cat("循环 ", loopp, "/", loop, "\n")
   set.seed(201 + crep *10)    
    # 为当前循环初始化临时数组
    parsur_temp <- array(0, dim = c(length(values), length(values), length(values)))
    surv_temp <- array(0, dim = c(length(values), length(values), length(values)))
    
    # 遍历所有组合
    for (z_z_index in seq_along(values)) {
        for (z_s_index in seq_along(values)) {
            for (z_m_index in seq_along(values)) {
                
                z_z <- values[[z_z_index]]
                z_s <- values[[z_s_index]]
                z_m <- values[[z_m_index]]
                
                # 对每个个体计算
                individual_estimates <- numeric(n)
                individual_true <- numeric(n)
                
                for (i in 1:n) {
                    # 计算估计值
                    est <- surv_prob1(z_z, z_s, Z[i, ], 
                                      mean.lam0.b[loopp, ], 
                                      mean.gam.b[loopp,], 
                                      mean.L.se[loopp,], 
                                      omegaT[i], 
                                      mean.psd[loopp,],alpha1T)
                    
                    # 计算真实值
                    true_val <- surv_prob1(z_z, z_s, Z[i, ], 
                                          lam0.true.b, 
                                          gam.true.b, 
                                          c(L.se.true[1,], L.se.true[2,]), 
                                          omegaT[i], 
                                          psd.true, 
                                          alpha1T)
                    
                    individual_estimates[i] <- est
                    individual_true[i] <- true_val
                }
                
                # 计算平均值并存储
                parsur_temp[z_z_index, z_s_index, z_m_index] <- mean(individual_estimates)
                surv_temp[z_z_index, z_s_index, z_m_index] <- mean(individual_true)
            }
        }
    }
    
    # 存储当前循环的结果
    loop_E1[loopp, , , ] <- parsur_temp
    loop_tE1[loopp, , , ] <- surv_temp
}

# 计算总结统计量
# 1. 计算均值估计
E1 <- apply(loop_E1, c(2, 3, 4), mean)  # 平均估计值
tE1 <- apply(loop_tE1, c(2, 3, 4), mean)  # 平均真实值

# 2. 计算标准差
parsee_E1 <- apply(loop_E1, c(2, 3, 4), sd)  # 估计值的标准差

# 3. 计算每个位置的RMSE
RMSE_array <- array(0, dim = c(length(values), length(values), length(values)))

for (i in 1:length(values)) {
    for (j in 1:length(values)) {
        for (k in 1:length(values)) {
            # 提取所有循环中该位置的估计值
            estimates <- loop_E1[, i, j, k]
            true_values <- loop_tE1[, i, j, k]
            
            # 计算RMSE
            RMSE_array[i, j, k] <- sqrt(mean((estimates - true_values)^2))
        }
    }
}

cat("\n=== 计算结果 ===\n")
cat("E1 (平均估计值):\n")
print(E1)

cat("\ntE1 (平均真实值):\n")
print(tE1)

cat("\nparsee_E1 (估计值标准差):\n")
print(parsee_E1)

cat("\nRMSE_array (均方根误差):\n")
print(RMSE_array)

# 计算效果量
# 假设位置对应关系：1对应值0，2对应值1
# 总效应：E[1,1,1] -> E[2,2,2]
ete_draws <- loop_E1[, 2, 2, 2] - loop_E1[, 1, 1, 1]
ede_draws <- loop_E1[, 2, 2, 2] - loop_E1[, 1, 2, 2]
eie1_m1_draws <- loop_E1[, 2, 2, 2] - loop_E1[, 2, 1, 2]
eie1_m2_draws <- loop_E1[, 2, 2, 2] - loop_E1[, 2, 2, 1]

# 真实效果量
true_ete <- tE1[2, 2, 2] - tE1[1, 1, 1]
true_ede <- tE1[2, 2, 2] - tE1[1, 2, 2]
true_eie_m1 <- tE1[2, 2, 2] - tE1[2, 1, 2]
true_eie_m2 <- tE1[2, 2, 2] - tE1[2, 2, 1]

# 计算RMSE
RMSE_ete1 <- sqrt(mean((ete_draws - true_ete)^2))
RMSE_ede1 <- sqrt(mean((ede_draws - true_ede)^2))
RMSE_eie1_m1 <- sqrt(mean((eie1_m1_draws - true_eie_m1)^2))
RMSE_eie1_m2 <- sqrt(mean((eie1_m2_draws - true_eie_m2)^2))

# 其他统计量
mean_ete1 <- mean(ete_draws)
mean_ede1 <- mean(ede_draws)
mean_eie1_m1 <- mean(eie1_m1_draws)
mean_eie1_m2 <- mean(eie1_m2_draws)

bias_ete1 <- mean_ete1 - true_ete
bias_ede1 <- mean_ede1 - true_ede
bias_eie1_m1 <- mean_eie1_m1 - true_eie_m1
bias_eie1_m2 <- mean_eie1_m2 - true_eie_m2

sd_ete1 <- sd(ete_draws)
sd_ede1 <- sd(ede_draws)
sd_eie1_m1 <- sd(eie1_m1_draws)
sd_eie1_m2 <- sd(eie1_m2_draws)

# 创建结果表格
result2 <- data.frame(
  Effect = c("Total_Effect", "Direct_Effect", "IE_via_M1", "IE_via_M2"),
  True_Value = c(true_ete, true_ede, true_eie_m1, true_eie_m2),
  Estimate = c(mean_ete1, mean_ede1, mean_eie1_m1, mean_eie1_m2),
  Bias = c(bias_ete1, bias_ede1, bias_eie1_m1, bias_eie1_m2),
  RMSE = c(RMSE_ete1, RMSE_ede1, RMSE_eie1_m1, RMSE_eie1_m2),
  SD = c(sd_ete1, sd_ede1, sd_eie1_m1, sd_eie1_m2)
)

cat("\n=== 效果量分析 ===\n")
print(result2)


###############################c#################################
load("D:\\Desktop\\MULTI-STATE-电脑2\\元旦后最后一次修改\\次要问题一——箱线图绘制_原程序\\lam.c共轭gibbs-n=500,,h=2T+1\\100.Rdata")

library(MASS)
library(HI)
library(coda)
library(MCMCpack)

values <- list(0, 1)

# 定义循环次数
loop <- 100  # 假设进行100次循环/模拟

# 创建数组存储多次模拟结果
# 维度：[循环次数, z_z, z_s, z_m]
loop_E1 <- array(0, dim = c(loop, length(values), length(values), length(values)))
loop_tE1 <- array(0, dim = c(loop, length(values), length(values), length(values)))

surv_prob1 <- function(z_z, z_s, x, hpost, AT, DeltaT, omega, cpsd, calpha1t) {
    nhcut <- 5
    t <- median(X[, 1])
    hcut <- quantile(X[, 1], seq(0, 1, 1 / nhcut))
    
    idx <- sum(t > hcut)
    idx <- min(idx, length(hcut) - 1)
    trpz_itgr <- 0.5 * t * (hpost[1] + hpost[idx])
    
    beta_0 = cbind(DeltaT[1], DeltaT[8])
    beta_x = cbind(DeltaT[2:5], DeltaT[9:12])
    beta_s1 = cbind(DeltaT[6], DeltaT[13])
    
    cAT = AT[1:4]
    zAT1 = AT[5]
    mAT1 = AT[7:8]
    
    M_X1 <- beta_0 + x %*% beta_x + z_s %*% beta_s1 + 
            mvrnorm(1, rep(0, q), diag(cpsd, q))
    
    ypost1 <- x %*% cAT + z_z %*% zAT1 + M_X1 %*% mAT1 + calpha1t * omega
 
    sur_prob1 <- colMeans(exp(-as.vector(trpz_itgr) %*% exp(ypost1)))
    return(sur_prob1)
}


 
# 外部循环 - 多次模拟
for (loopp in 1:loop) {
    cat("循环 ", loopp, "/", loop, "\n")
    set.seed(201 + crep *10)   
    # 为当前循环初始化临时数组
    parsur_temp <- array(0, dim = c(length(values), length(values), length(values)))
    surv_temp <- array(0, dim = c(length(values), length(values), length(values)))
    
    # 遍历所有组合
    for (z_z_index in seq_along(values)) {
        for (z_s_index in seq_along(values)) {
            for (z_m_index in seq_along(values)) {
                
                z_z <- values[[z_z_index]]
                z_s <- values[[z_s_index]]
                z_m <- values[[z_m_index]]
                
                # 对每个个体计算
                individual_estimates <- numeric(n)
                individual_true <- numeric(n)
                
                for (i in 1:n) {
                    # 计算估计值
                    est <- surv_prob1(z_z, z_s, Z[i, ], 
                                      mean.lam0.c[loopp, ], 
                                      mean.gam.c[loopp,], 
                                      mean.L.se[loopp,], 
                                      omegaT[i], 
                                      mean.psd[loopp,],alpha2T)
                    
                    # 计算真实值
                    true_val <- surv_prob1(z_z, z_s, Z[i, ], 
                                          lam0.true.c, 
                                          gam.true.c, 
                                          c(L.se.true[1,], L.se.true[2,]), 
                                          omegaT[i], 
                                          psd.true, 
                                          alpha2T)
                    
                    individual_estimates[i] <- est
                    individual_true[i] <- true_val
                }
                
                # 计算平均值并存储
                parsur_temp[z_z_index, z_s_index, z_m_index] <- mean(individual_estimates)
                surv_temp[z_z_index, z_s_index, z_m_index] <- mean(individual_true)
            }
        }
    }
    
    # 存储当前循环的结果
    loop_E1[loopp, , , ] <- parsur_temp
    loop_tE1[loopp, , , ] <- surv_temp
}

# 计算总结统计量
# 1. 计算均值估计
E1 <- apply(loop_E1, c(2, 3, 4), mean)  # 平均估计值
tE1 <- apply(loop_tE1, c(2, 3, 4), mean)  # 平均真实值

# 2. 计算标准差
parsee_E1 <- apply(loop_E1, c(2, 3, 4), sd)  # 估计值的标准差

# 3. 计算每个位置的RMSE
RMSE_array <- array(0, dim = c(length(values), length(values), length(values)))

for (i in 1:length(values)) {
    for (j in 1:length(values)) {
        for (k in 1:length(values)) {
            # 提取所有循环中该位置的估计值
            estimates <- loop_E1[, i, j, k]
            true_values <- loop_tE1[, i, j, k]
            
            # 计算RMSE
            RMSE_array[i, j, k] <- sqrt(mean((estimates - true_values)^2))
        }
    }
}

cat("\n=== 计算结果 ===\n")
cat("E1 (平均估计值):\n")
print(E1)

cat("\ntE1 (平均真实值):\n")
print(tE1)

cat("\nparsee_E1 (估计值标准差):\n")
print(parsee_E1)

cat("\nRMSE_array (均方根误差):\n")
print(RMSE_array)

# 计算效果量
# 假设位置对应关系：1对应值0，2对应值1
# 总效应：E[1,1,1] -> E[2,2,2]
ete_draws <- loop_E1[, 2, 2, 2] - loop_E1[, 1, 1, 1]
ede_draws <- loop_E1[, 2, 2, 2] - loop_E1[, 1, 2, 2]
eie1_m1_draws <- loop_E1[, 2, 2, 2] - loop_E1[, 2, 1, 2]
eie1_m2_draws <- loop_E1[, 2, 2, 2] - loop_E1[, 2, 2, 1]

# 真实效果量
true_ete <- tE1[2, 2, 2] - tE1[1, 1, 1]
true_ede <- tE1[2, 2, 2] - tE1[1, 2, 2]
true_eie_m1 <- tE1[2, 2, 2] - tE1[2, 1, 2]
true_eie_m2 <- tE1[2, 2, 2] - tE1[2, 2, 1]

# 计算RMSE
RMSE_ete1 <- sqrt(mean((ete_draws - true_ete)^2))
RMSE_ede1 <- sqrt(mean((ede_draws - true_ede)^2))
RMSE_eie1_m1 <- sqrt(mean((eie1_m1_draws - true_eie_m1)^2))
RMSE_eie1_m2 <- sqrt(mean((eie1_m2_draws - true_eie_m2)^2))

# 其他统计量
mean_ete1 <- mean(ete_draws)
mean_ede1 <- mean(ede_draws)
mean_eie1_m1 <- mean(eie1_m1_draws)
mean_eie1_m2 <- mean(eie1_m2_draws)

bias_ete1 <- mean_ete1 - true_ete
bias_ede1 <- mean_ede1 - true_ede
bias_eie1_m1 <- mean_eie1_m1 - true_eie_m1
bias_eie1_m2 <- mean_eie1_m2 - true_eie_m2

sd_ete1 <- sd(ete_draws)
sd_ede1 <- sd(ede_draws)
sd_eie1_m1 <- sd(eie1_m1_draws)
sd_eie1_m2 <- sd(eie1_m2_draws)

# 创建结果表格
result3 <- data.frame(
  Effect = c("Total_Effect", "Direct_Effect", "IE_via_M1", "IE_via_M2"),
  True_Value = c(true_ete, true_ede, true_eie_m1, true_eie_m2),
  Estimate = c(mean_ete1, mean_ede1, mean_eie1_m1, mean_eie1_m2),
  Bias = c(bias_ete1, bias_ede1, bias_eie1_m1, bias_eie1_m2),
  RMSE = c(RMSE_ete1, RMSE_ede1, RMSE_eie1_m1, RMSE_eie1_m2),
  SD = c(sd_ete1, sd_ede1, sd_eie1_m1, sd_eie1_m2)
)

cat("\n=== 效果量分析 ===\n")
print(result1)
print(result2)
print(result3)

