script_dir <- function() {
  args <- commandArgs(FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (length(file_arg) > 0L) {
    return(dirname(normalizePath(sub("^--file=", "", file_arg[[1L]]), winslash = "/", mustWork = FALSE)))
  }
  normalizePath(getwd(), winslash = "/", mustWork = FALSE)
}

arg_value <- function(prefix, default = NULL) {
  hit <- grep(paste0("^", prefix), commandArgs(TRUE), value = TRUE)
  if (length(hit) == 0L) return(default)
  sub(paste0("^", prefix), "", hit[[1L]])
}

arg_int <- function(prefix, default) {
  value <- arg_value(prefix, as.character(default))
  as.integer(value)
}

root <- script_dir()
engine_file <- file.path(root, "model_engine.dat")
if (!file.exists(engine_file)) {
  stop("model_engine.dat is missing. Keep it in the same folder as run_analysis.R.", call. = FALSE)
}

quick <- "--quick" %in% commandArgs(TRUE)
default_output <- if (quick) "quick_results" else "results"
output_dir <- arg_value("--out=", file.path(root, default_output))
run_model <- readRDS(engine_file)

if (quick) {
  run_model(
    output_dir = output_dir,
    rep_num = arg_int("--rep_num=", 1L),
    n = arg_int("--n=", 20L),
    n_mcmc = arg_int("--n_mcmc=", 3L),
    n_kept = arg_int("--n_kept=", 1L),
    seed = arg_int("--seed=", 1L),
    verbose = TRUE
  )
} else {
  run_model(
    output_dir = output_dir,
    rep_num = arg_int("--rep_num=", 100L),
    n = arg_int("--n=", 500L),
    n_mcmc = arg_int("--n_mcmc=", 20000L),
    n_kept = arg_int("--n_kept=", 10000L),
    seed = arg_int("--seed=", 1L),
    verbose = TRUE
  )
}
