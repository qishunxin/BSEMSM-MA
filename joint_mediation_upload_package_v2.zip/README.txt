This is a compact upload package.

Upload these two files together:

1. run_analysis.R
2. model_engine.dat

Quick check:

Rscript run_analysis.R --quick

Full run with the original settings:

Rscript run_analysis.R

Optional arguments:

--out=PATH
--rep_num=N
--n=N
--n_mcmc=N
--n_kept=N
--seed=N

Example:

Rscript run_analysis.R --quick --out=quick_results

Note:

model_engine.dat is a serialized R object. It avoids uploading the full plain-text script directly, but it is not cryptographic protection.
